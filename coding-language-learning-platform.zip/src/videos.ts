export type VideoItem = {
  /** Identifiant de la vidéo YouTube (11 caractères). */
  id: string;
  title: string;
  channel: string;
};

export type ChannelItem = {
  name: string;
  url: string;
  topics: string;
  /** Indique un lien direct (vrai) ou une recherche YouTube (faux). */
  direct: boolean;
};

/** Vidéos francophones sélectionnées, classées par cours. */
export const videoCatalog: Record<string, VideoItem[]> = {
  javascript: [
    {
      id: "Ny3iznrppnU",
      title: "Apprendre JavaScript — Cours complet",
      channel: "Cours JavaScript FR",
    },
    {
      id: "B2W_NHDax5w",
      title: "HTML, CSS & JavaScript par la pratique",
      channel: "Graven",
    },
  ],
  python: [
    {
      id: "oUJolR5bX6g",
      title: "Apprendre Python — Tuto complet débutant",
      channel: "Graven",
    },
    {
      id: "QMb0fjH5Rjg",
      title: "Python : cours complet pour débutants",
      channel: "ETC School",
    },
  ],
  "html-css": [
    {
      id: "Tnym_6qCcNE",
      title: "HTML & CSS : les bases pour créer un site",
      channel: "Tuto web FR",
    },
    {
      id: "B2W_NHDax5w",
      title: "HTML, CSS & JavaScript par la pratique",
      channel: "Graven",
    },
  ],
  sql: [
    {
      id: "eL80VI4QGTg",
      title: "Apprendre SQL — Tutoriel complet",
      channel: "Dataseito",
    },
    {
      id: "iHKE_4KeNWQ",
      title: "Apprendre et maîtriser le SQL",
      channel: "Grafikart",
    },
  ],
  java: [
    {
      id: "SvPGiy5UXRI",
      title: "Apprendre Java — Les variables",
      channel: "Graven",
    },
  ],
  c: [
    {
      id: "BxEtijI9uJE",
      title: "Apprendre à coder en C — Présentation",
      channel: "Codeurs Pro",
    },
  ],
};

/** Onglets de filtrage des vidéos par langage. */
export const videoLanguages = [
  { id: "Tous", label: "Tous" },
  { id: "javascript", label: "JavaScript" },
  { id: "python", label: "Python" },
  { id: "html-css", label: "HTML/CSS" },
  { id: "sql", label: "SQL" },
  { id: "java", label: "Java" },
  { id: "c", label: "C" },
];

/** Chaînes YouTube francophones recommandées (couvrent tous les langages). */
export const recommendedChannels: ChannelItem[] = [
  {
    name: "Grafikart",
    url: "https://www.youtube.com/user/grafikarttv",
    topics: "HTML · CSS · JavaScript · PHP · SQL",
    direct: true,
  },
  {
    name: "FormationVidéo",
    url: "https://www.youtube.com/channel/UCS2e0hEJMhwd6bNscS60xTg",
    topics: "C · C++ · Python · Java · JS · PHP · SQL",
    direct: true,
  },
  {
    name: "Pierre Giraud",
    url: "https://www.pierre-giraud.com",
    topics: "HTML/CSS · Java · JavaScript · PHP · SQL",
    direct: true,
  },
  {
    name: "Graven",
    url: "https://www.youtube.com/results?search_query=Graven+programmation",
    topics: "Python · Java · JavaScript · Mobile",
    direct: false,
  },
  {
    name: "From Scratch",
    url: "https://www.youtube.com/results?search_query=From+Scratch+d%C3%A9veloppement",
    topics: "Développement web front & back",
    direct: false,
  },
];

/** Construit l'URL d'une miniature YouTube. */
export function thumbUrl(id: string) {
  return `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
}

/** Construit l'URL courte de partage YouTube. */
export function watchUrl(id: string) {
  return `https://www.youtube.com/watch?v=${id}`;
}
